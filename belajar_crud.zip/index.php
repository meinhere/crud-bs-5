<?php
session_start();
require 'functions.php';

$siswa = query("SELECT * FROM tb_siswa");
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	
	<!-- Templates CSS -->
	<link rel="stylesheet" href="BS/css/bootstrap.min.css">
	<link rel="stylesheet" href="fonts/css/font-awesome.min.css">
	<link rel="stylesheet" href="datatables/datatables.css">

	<title>Halaman Beranda || Belajar CRUD</title>
</head>

<body>
	<!-- Start Navbar -->
	<nav class="navbar navbar-dark bg-dark">
		<div class="container-fluid">
			<a href="index.php" class="navbar-brand">
				<i class="fa fa-rocket"></i>
				CRUD - Bootstrap 5
			</a>
		</div>
	</nav>
	<!-- End Navbar -->

	<div class="container mb-4">
		<!-- Notify Warning -->
		<?php if (isset($_SESSION['warning'])) : ?>
			<div class="alert alert-danger alert-dismissible fade show mt-3" role="alert">
				<h2 class="text-danger text-center"><?= $_SESSION['warning']; ?></h2>
				<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
			</div>
		<?php session_destroy(); ?>
		<?php endif; ?>
		
		<!-- Start Header -->
		<div class="row">
			<div class="col-sm-6">
				<figure class="mt-4">
					<h1>Data Siswa</h1>
					<blockquote class="blockquote">
						<p>Berikut berisi data siswa kelas XII - TKJ 1</p>
					</blockquote>
					<figcaption class="blockquote-footer">
						CRUD <cite title="Source Title">Create - Read - Update - Delete</cite>
					</figcaption>
				</figure>

				<a href="kelola.php" class="btn btn-primary mb-4">
					<i class="fa fa-plus"></i>
					Tambah Data
				</a>
			</div>
		</div>
		<!-- End Header -->

		<!-- Notify Success -->
		<?php if (isset($_SESSION['berhasil'])) : ?>
			<div class="alert alert-success alert-dismissible fade show" role="alert">
				<?= $_SESSION['berhasil']; ?>
				<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
			</div>
		<?php session_destroy(); ?>
		<?php endif; ?>

		<!-- Start Table Data -->
		<div class="table-responsive">
			<table class="table align-middle table-bordered table-hover" id="dt">
				<thead>
					<tr>
						<th class="text-center">No</th>
						<th>NISN</th>
						<th>Nama Siswa</th>
						<th>Jenis Kelamin</th>
						<th class="text-center">Foto Siswa</th>
						<th>Alamat</th>
						<th class="text-center">Aksi</th>
					</tr>
				</thead>
				<tbody>
					<?php $i = 1; ?>
					<?php foreach ($siswa as $row) : ?>
					<tr>
						<td class="text-center"><?= $i++; ?></td>
						<td><?= $row['nisn']; ?></td>
						<td><?= $row['nama_siswa']; ?></td>
						<td><?= $row['jenis_kelamin']; ?></td>
						<td class="text-center">
							<img src="img/<?= $row['foto_siswa']; ?>" style="width: 100px;">
						</td>
						<td><?= $row['alamat']; ?></td>
						<td class="text-center">
							<a href="kelola.php?ubah=<?= $row['id_siswa']; ?>" class="btn btn-success btn-sm">
								<i class="fa fa-pencil"></i>
							</a>
							<a href="proses.php?hapus=<?= $row['id_siswa']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Apakah Anda Yakin ?')">
								<i class="fa fa-trash"></i>
							</a>
						</td>
					</tr>
					<?php endforeach ?>
				</tbody>
			</table>
		</div>
		<!-- End Table Data -->
	</div>

	<!-- Templates Javascript -->
	<script src="BS/js/bootstrap.bundle.min.js"></script>
	<script src="datatables/datatables.js"></script>
	<!-- Custom Javascript -->
	<script>
		$(document).ready(function() {
			$('#dt').DataTable();
		});
	</script>
</body>

</html>