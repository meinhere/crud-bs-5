<?php
session_start();
require 'functions.php';

if (isset($_GET['ubah'])) {
	if (strlen($_GET['ubah']) > 4) {
		$_SESSION['warning'] = "ANDA MAU NGAPAIN ??";
		header('Location: index.php');
		exit();
	}

	$id = $_GET['ubah'];
	$siswa = query("SELECT * FROM tb_siswa WHERE id_siswa = $id");
} else {
	$query = [
		'id_siswa' 						=> '',
		'nisn'								=> '',
		'nama_siswa'					=> '',
		'jenis_kelamin'				=> '',
		'foto_siswa'					=> '',
		'alamat'							=> '',
	];

	$siswa = [$query];
}
?>

<!DOCTYPE html>
<html>

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<!-- Templates CSS -->
	<link rel="stylesheet" href="BS/css/bootstrap.min.css">
	<link rel="stylesheet" href="fonts/css/font-awesome.min.css">

	<?php if (isset($_GET['ubah'])) : ?>
		<title>Halaman Ubah Data || Belajar CRUD</title>
	<?php else : ?>
		<title>Halaman Tambah Data || Belajar CRUD</title>
	<?php endif; ?>
</head>

<body>
	<!-- Start Navbar -->
	<nav class="navbar navbar-light bg-light">
		<div class="container-fluid">
			<a href="index.php" class="navbar-brand">
				<i class="fa fa-rocket"></i>
				CRUD - Bootstrap 5
			</a>
		</div>
	</nav>
	<!-- End Navbar -->

	<div class="container mb-3">
		<?php if (isset($_GET['ubah'])) : ?>
			<h2 class="mb-4 mt-4">Form Ubah Data</h2>
		<?php else : ?>
			<h2 class="mb-4 mt-4">Form Tambah Data</h2>
		<?php endif; ?>
		
		<!-- Notify Error -->
		<?php if (isset($_COOKIE['pesan'])) : ?>
			<div class="alert alert-danger alert-dismissible fade show" role="alert">
				<?= $_COOKIE['pesan']?>
				<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
			</div>
		<?php endif; ?>

		<!-- Start Form Input -->
		<form action="proses.php" method="post" enctype="multipart/form-data">
			<?php foreach ($siswa as $row) : ?>
				<input type="hidden" name="id_siswa" value="<?= $row['id_siswa']?>">
				<input type="hidden" name="fotoLama" value="<?= $row['foto_siswa']; ?>">
				<div class="mb-3 row">
					<label for="nisn" class="col-sm-4 col-md-2 col-form-label">NISN</label>
					<div class="col-sm-8 col-md-10">
						<input type="text" name="nisn" id="nisn" class="form-control" placeholder="Ex: 112233" value="<?= (isset($_COOKIE['pesan'])) ? $_SESSION['nisn'] : $row['nisn']; ?>" <?= (isset($_GET['ubah'])) ? 'readonly' : ''; ?>>
					</div>
				</div>
				<div class="mb-3 row">
					<label for="nama" class="col-sm-4 col-md-2 col-form-label">Nama Siswa</label>
					<div class="col-sm-8 col-md-10">
						<input type="text" name="nama" id="nama" class="form-control" placeholder="Ex: Alpha Rector" value="<?= (isset($_COOKIE['pesan'])) ? $_SESSION['nama'] : $row['nama_siswa']; ?>">
					</div>
				</div>
				<div class="mb-3 row">
					<label for="jkel" class="col-sm-4 col-md-2 col-form-label">Jenis Kelamin</label>
					<div class="col-sm-8 col-md-10">
						<?php $jkel = (isset($_SESSION['jkel'])) ? $_SESSION['jkel'] : '' ; ?>
						<select class="form-select" name="jkel" id="jkel">
							<?php if ($row['jenis_kelamin'] == 'Laki-Laki' || $jkel == 'Laki-Laki') : ?>
								<option value="0">Pilih Jenis Kelamin</option>
								<option value="Laki-Laki" selected>Laki-Laki</option>
								<option value="Perempuan" || >Perempuan</option>
							<?php elseif ($row['jenis_kelamin'] == 'Perempuan' || $jkel == 'Perempuan') : ?>
								<option value="0">Pilih Jenis Kelamin</option>
								<option value="Laki-Laki">Laki-Laki</option>
								<option value="Perempuan" selected>Perempuan</option>
							<?php else : ?>
								<option value="0" selected>Pilih Jenis Kelamin</option>
								<option value="Laki-Laki">Laki-Laki</option>
								<option value="Perempuan">Perempuan</option>
							<?php endif; ?>
						</select>
					</div>
				</div>
				<div class="mb-3 row">
					<label for="foto" class="col-sm-4 col-md-2 col-form-label d-flex" style="align-items: center;">Foto Siswa</label>
					<div class="col-sm-8 col-md-2 text-center mb-3">
						<div class="img-boy">
							<span class="d-block mb-1">Laki-Laki</span>
							<img src="img/boy.svg" class="img-thumbnail mb-4" style="width: 80px;">
						</div>
						<div class="img-girl">
							<span class="d-block mb-1">Perempuan</span>
							<img src="img/girl.svg" class="img-thumbnail" style="width: 80px;">
						</div>
					</div>
					<div class="col-sm-4 col-md-2 d-flex align-items-center justify-content-center">
							<img src="img/<?= ( $row['foto_siswa'] == '' ) ? 'default.svg' : $row['foto_siswa'] ; ?>" class="img-thumbnail img-prev" style="width: 200px;">
					</div>
					<div class="col-sm-8 col-md-6 d-flex align-items-center mt-3">
						<input class="form-control" type="file" name="foto" id="foto" onchange="previewImg()">
					</div>
				</div>
				<div class="mb-4 row">
					<label for="alamat" class="col-sm-4 col-md-2 col-form-label">Alamat</label>
						<div class="col-sm-8 col-md-10">
							<textarea class="form-control" name="alamat" id="alamat" placeholder="Ex: Kec. Tanjuganom Kab. Nganjuk"><?= (isset($_COOKIE['pesan'])) ? $_SESSION['alamat'] :  $row['alamat']; ?></textarea>
						</div>
				</div>
			<?php session_destroy(); ?>
			<?php endforeach; ?>

			<?php if (isset($_GET['ubah'])) : ?>
				<button type="submit" name="ubah" class="btn btn-primary">
					<i class="fa fa-floppy-o"></i>
					Simpan Perubahan
				</button>
			<?php else : ?>
				<button type="submit" name="tambah" class="btn btn-primary">
					<i class="fa fa-floppy-o"></i>
					Tambahkan
				</button>
			<?php endif; ?>
				<a href="index.php" class="btn btn-danger">
					<i class="fa fa-reply"></i>
					Kembali
				</a>
		</form>
		<!-- End Form Input -->
	</div>

	<!-- Templates Javascript -->
	<script src="BS/js/bootstrap.bundle.min.js"></script>
	<!-- Custom Javascript -->
	<script>
		function previewImg() {
			const foto = document.querySelector('#foto');
			const fotoSiswa = document.querySelector('.img-prev');

			const fileFoto = new FileReader();
			fileFoto.readAsDataURL(foto.files[0]);

			fileFoto.onload = function(e) {
				fotoSiswa.src = e.target.result;
			}
		}
	</script>

</body>
</html>