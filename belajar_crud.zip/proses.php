<?php
session_start();
require 'functions.php';

if (isset($_POST['tambah'])) {

	if (tambah($_POST) > 0) {
		$result = query("SELECT * FROM tb_siswa");
		$result = end($result);
		$rowAkhir = $result['id_siswa'];
		$_SESSION['berhasil'] = "Data Dengan Nama : <a href='kelola.php?ubah=$rowAkhir' class='alert-link'>". $_POST['nama'] ."</a> Berhasil Ditambahkan";
		header("Location: index.php");
		exit();
	} else {
		$_SESSION['nisn'] = $_POST['nisn'];
		$_SESSION['nama'] = $_POST['nama'];
		$_SESSION['jkel'] = $_POST['jkel'];
		$_SESSION['alamat'] = $_POST['alamat'];
		header("Location: kelola.php");
		exit();
	}
}

if (isset($_POST['ubah'])) {
	$id = $_POST['id_siswa'];

	if (ubah($_POST) > 0) {
		$_SESSION['berhasil'] = "Data Dengan Nama : <a href='kelola.php?ubah=$id' class='alert-link'>". $_POST['nama'] ."</a> Berhasil Diubah";
		header("Location: index.php");
		exit();
	} elseif (ubah($_POST) == 0) {
		setcookie("pesan", "Data tidak ada yang berubah, silahkan ulangi kembali", time() + 1);
		$_SESSION['nisn'] = $_POST['nisn'];
		$_SESSION['nama'] = $_POST['nama'];
		$_SESSION['jkel'] = $_POST['jkel'];
		$_SESSION['alamat'] = $_POST['alamat'];
		header("Location: kelola.php?ubah=" . $id);
		exit();
	} else {
		$_SESSION['nisn'] = $_POST['nisn'];
		$_SESSION['nama'] = $_POST['nama'];
		$_SESSION['jkel'] = $_POST['jkel'];
		$_SESSION['alamat'] = $_POST['alamat'];
		header("Location: kelola.php?ubah=" . $id);
		exit();
	}
}

if (isset($_GET['hapus'])) {
	$id = $_GET['hapus'];
	$result = query("SELECT nama_siswa FROM tb_siswa WHERE id_siswa = $id")[0];
	$nama = $result['nama_siswa'];

	if (strlen($_GET['hapus']) > 4) {
		$_SESSION['warning'] = "ANDA MAU NGAPAIN ??";
		header('Location: index.php');
		exit();
	}

	if (hapus($id) > 0) {
		$_SESSION['berhasil'] = "Data Dengan Nama : <span class='fw-bold'>" . $nama . "</span> Berhasil Dihapus";
		header("Location: index.php");
		exit();
	} else {
		$_SESSION['berhasil'] = 'Data Gagal Dihapus';
		header("Location: index.php");
		exit();
	}
}